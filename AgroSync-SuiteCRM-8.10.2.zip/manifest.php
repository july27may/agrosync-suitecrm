<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2018 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

$manifest = array (
  0 => 
  array (
    'acceptable_sugar_versions' => 
    array (
      0 => '6.5.25',
    ),
  ),
  1 => 
  array (
    'acceptable_sugar_flavors' => 
    array (
      0 => 'CE',
    ),
  ),
  'readme' => '',
  'key' => 'ags',
  'author' => 'Julián Andrés Galvis Castaño',
  'description' => 'Módulos de gestión cafetera, ganadera e inventarios de AgroSync.',
  'icon' => '',
  'is_uninstallable' => true,
  'name' => 'AgroSync',
  'published_date' => '2026-11-19 20:41:47',
  'type' => 'module',
  'version' => 1795120907,
  'remove_tables' => 'prompt',
  'acceptable_suitecrm_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '8.10.2',
    ),
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.5.25',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
);

$installdefs = array (
  'id' => 'AgroSync',
  'beans' => 
  array (
    0 => 
    array (
      'module' => 'ags_movimientos_inventario',
      'class' => 'ags_movimientos_inventario',
      'path' => 'modules/ags_movimientos_inventario/ags_movimientos_inventario.php',
      'tab' => 1,
    ),
    1 => 
    array (
      'module' => 'ags_eventos_sanitarios',
      'class' => 'ags_eventos_sanitarios',
      'path' => 'modules/ags_eventos_sanitarios/ags_eventos_sanitarios.php',
      'tab' => 1,
    ),
    2 => 
    array (
      'module' => 'ags_animales',
      'class' => 'ags_animales',
      'path' => 'modules/ags_animales/ags_animales.php',
      'tab' => 1,
    ),
    3 => 
    array (
      'module' => 'ags_Fincas',
      'class' => 'ags_Fincas',
      'path' => 'modules/ags_Fincas/ags_Fincas.php',
      'tab' => true,
    ),
    4 => 
    array (
      'module' => 'ags_insumos',
      'class' => 'ags_insumos',
      'path' => 'modules/ags_insumos/ags_insumos.php',
      'tab' => 1,
    ),
    5 => 
    array (
      'module' => 'ags_labores',
      'class' => 'ags_labores',
      'path' => 'modules/ags_labores/ags_labores.php',
      'tab' => 1,
    ),
    6 => 
    array (
      'module' => 'ags_veredas',
      'class' => 'ags_veredas',
      'path' => 'modules/ags_veredas/ags_veredas.php',
      'tab' => true,
    ),
    7 => 
    array (
      'module' => 'ags_cosechas',
      'class' => 'ags_cosechas',
      'path' => 'modules/ags_cosechas/ags_cosechas.php',
      'tab' => 1,
    ),
    8 => 
    array (
      'module' => 'ags_lotes',
      'class' => 'ags_lotes',
      'path' => 'modules/ags_lotes/ags_lotes.php',
      'tab' => true,
    ),
    9 => 
    array (
      'module' => 'ags_departamentos',
      'class' => 'ags_departamentos',
      'path' => 'modules/ags_departamentos/ags_departamentos.php',
      'tab' => true,
    ),
    10 => 
    array (
      'module' => 'ags_municipios',
      'class' => 'ags_municipios',
      'path' => 'modules/ags_municipios/ags_municipios.php',
      'tab' => true,
    ),
  ),
  'layoutdefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/ags_departamentos_ags_municipios_ags_departamentos.php',
      'to_module' => 'ags_departamentos',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/ags_municipios_ags_veredas_ags_municipios.php',
      'to_module' => 'ags_municipios',
    ),
  ),
  'relationships' => 
  array (
    0 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/ags_departamentos_ags_municipiosMetaData.php',
    ),
    1 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/ags_municipios_ags_veredasMetaData.php',
    ),
  ),
  'image_dir' => '<basepath>/icons',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_movimientos_inventario',
      'to' => 'modules/ags_movimientos_inventario',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_eventos_sanitarios',
      'to' => 'modules/ags_eventos_sanitarios',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_animales',
      'to' => 'modules/ags_animales',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_Fincas',
      'to' => 'modules/ags_Fincas',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_insumos',
      'to' => 'modules/ags_insumos',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_labores',
      'to' => 'modules/ags_labores',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_veredas',
      'to' => 'modules/ags_veredas',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_cosechas',
      'to' => 'modules/ags_cosechas',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_lotes',
      'to' => 'modules/ags_lotes',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_departamentos',
      'to' => 'modules/ags_departamentos',
    ),
    10 => 
    array (
      'from' => '<basepath>/SugarModules/modules/ags_municipios',
      'to' => 'modules/ags_municipios',
    ),
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ags_municipios.php',
      'to_module' => 'ags_municipios',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ags_municipios.php',
      'to_module' => 'ags_municipios',
      'language' => 'es_MX',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ags_departamentos.php',
      'to_module' => 'ags_departamentos',
      'language' => 'en_us',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ags_departamentos.php',
      'to_module' => 'ags_departamentos',
      'language' => 'es_MX',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ags_veredas.php',
      'to_module' => 'ags_veredas',
      'language' => 'en_us',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ags_veredas.php',
      'to_module' => 'ags_veredas',
      'language' => 'es_MX',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ags_municipios.php',
      'to_module' => 'ags_municipios',
      'language' => 'en_us',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/ags_municipios.php',
      'to_module' => 'ags_municipios',
      'language' => 'es_MX',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/language/application/en_us.lang.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/language/application/es_MX.lang.php',
      'to_module' => 'application',
      'language' => 'es_MX',
    ),
  ),
  'vardefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ags_departamentos_ags_municipios_ags_municipios.php',
      'to_module' => 'ags_municipios',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ags_departamentos_ags_municipios_ags_departamentos.php',
      'to_module' => 'ags_departamentos',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ags_municipios_ags_veredas_ags_veredas.php',
      'to_module' => 'ags_veredas',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/ags_municipios_ags_veredas_ags_municipios.php',
      'to_module' => 'ags_municipios',
    ),
  ),
  'layoutfields' => 
  array (
    0 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    1 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
  ),
);
