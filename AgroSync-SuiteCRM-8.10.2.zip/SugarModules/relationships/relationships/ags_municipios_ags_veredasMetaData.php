<?php
// created: 2026-11-19 15:41:47
$dictionary["ags_municipios_ags_veredas"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'ags_municipios_ags_veredas' => 
    array (
      'lhs_module' => 'ags_municipios',
      'lhs_table' => 'ags_municipios',
      'lhs_key' => 'id',
      'rhs_module' => 'ags_veredas',
      'rhs_table' => 'ags_veredas',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'ags_municipios_ags_veredas_c',
      'join_key_lhs' => 'ags_municipios_ags_veredasags_municipios_ida',
      'join_key_rhs' => 'ags_municipios_ags_veredasags_veredas_idb',
    ),
  ),
  'table' => 'ags_municipios_ags_veredas_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'ags_municipios_ags_veredasags_municipios_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'ags_municipios_ags_veredasags_veredas_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'ags_municipios_ags_veredasspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'ags_municipios_ags_veredas_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'ags_municipios_ags_veredasags_municipios_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'ags_municipios_ags_veredas_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'ags_municipios_ags_veredasags_veredas_idb',
      ),
    ),
  ),
);