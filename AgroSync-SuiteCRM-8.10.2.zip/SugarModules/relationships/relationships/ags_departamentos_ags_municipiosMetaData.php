<?php
// created: 2026-11-19 15:41:47
$dictionary["ags_departamentos_ags_municipios"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'ags_departamentos_ags_municipios' => 
    array (
      'lhs_module' => 'ags_departamentos',
      'lhs_table' => 'ags_departamentos',
      'lhs_key' => 'id',
      'rhs_module' => 'ags_municipios',
      'rhs_table' => 'ags_municipios',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'ags_departamentos_ags_municipios_c',
      'join_key_lhs' => 'ags_departamentos_ags_municipiosags_departamentos_ida',
      'join_key_rhs' => 'ags_departamentos_ags_municipiosags_municipios_idb',
    ),
  ),
  'table' => 'ags_departamentos_ags_municipios_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'ags_departamentos_ags_municipiosags_departamentos_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'ags_departamentos_ags_municipiosags_municipios_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'ags_departamentos_ags_municipiosspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'ags_departamentos_ags_municipios_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'ags_departamentos_ags_municipiosags_departamentos_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'ags_departamentos_ags_municipios_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'ags_departamentos_ags_municipiosags_municipios_idb',
      ),
    ),
  ),
);