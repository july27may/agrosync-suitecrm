<?php
// created: 2026-11-19 15:41:47
$dictionary["ags_departamentos"]["fields"]["ags_departamentos_ags_municipios"] = array (
  'name' => 'ags_departamentos_ags_municipios',
  'type' => 'link',
  'relationship' => 'ags_departamentos_ags_municipios',
  'source' => 'non-db',
  'module' => 'ags_municipios',
  'bean_name' => 'ags_municipios',
  'side' => 'right',
  'vname' => 'LBL_AGS_DEPARTAMENTOS_AGS_MUNICIPIOS_FROM_AGS_MUNICIPIOS_TITLE',
);
