<?php
// created: 2026-11-19 15:41:47
$dictionary["ags_municipios"]["fields"]["ags_municipios_ags_veredas"] = array (
  'name' => 'ags_municipios_ags_veredas',
  'type' => 'link',
  'relationship' => 'ags_municipios_ags_veredas',
  'source' => 'non-db',
  'module' => 'ags_veredas',
  'bean_name' => 'ags_veredas',
  'side' => 'right',
  'vname' => 'LBL_AGS_MUNICIPIOS_AGS_VEREDAS_FROM_AGS_VEREDAS_TITLE',
);
