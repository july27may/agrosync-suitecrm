<?php
// created: 2026-11-19 15:41:47
$dictionary["ags_veredas"]["fields"]["ags_municipios_ags_veredas"] = array (
  'name' => 'ags_municipios_ags_veredas',
  'type' => 'link',
  'relationship' => 'ags_municipios_ags_veredas',
  'source' => 'non-db',
  'module' => 'ags_municipios',
  'bean_name' => 'ags_municipios',
  'vname' => 'LBL_AGS_MUNICIPIOS_AGS_VEREDAS_FROM_AGS_MUNICIPIOS_TITLE',
  'id_name' => 'ags_municipios_ags_veredasags_municipios_ida',
);
$dictionary["ags_veredas"]["fields"]["ags_municipios_ags_veredas_name"] = array (
  'name' => 'ags_municipios_ags_veredas_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_AGS_MUNICIPIOS_AGS_VEREDAS_FROM_AGS_MUNICIPIOS_TITLE',
  'save' => true,
  'id_name' => 'ags_municipios_ags_veredasags_municipios_ida',
  'link' => 'ags_municipios_ags_veredas',
  'table' => 'ags_municipios',
  'module' => 'ags_municipios',
  'rname' => 'name',
);
$dictionary["ags_veredas"]["fields"]["ags_municipios_ags_veredasags_municipios_ida"] = array (
  'name' => 'ags_municipios_ags_veredasags_municipios_ida',
  'type' => 'link',
  'relationship' => 'ags_municipios_ags_veredas',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_AGS_MUNICIPIOS_AGS_VEREDAS_FROM_AGS_VEREDAS_TITLE',
);
