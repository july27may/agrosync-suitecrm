<?php
// created: 2026-11-19 15:41:47
$dictionary["ags_municipios"]["fields"]["ags_departamentos_ags_municipios"] = array (
  'name' => 'ags_departamentos_ags_municipios',
  'type' => 'link',
  'relationship' => 'ags_departamentos_ags_municipios',
  'source' => 'non-db',
  'module' => 'ags_departamentos',
  'bean_name' => 'ags_departamentos',
  'vname' => 'LBL_AGS_DEPARTAMENTOS_AGS_MUNICIPIOS_FROM_AGS_DEPARTAMENTOS_TITLE',
  'id_name' => 'ags_departamentos_ags_municipiosags_departamentos_ida',
);
$dictionary["ags_municipios"]["fields"]["ags_departamentos_ags_municipios_name"] = array (
  'name' => 'ags_departamentos_ags_municipios_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_AGS_DEPARTAMENTOS_AGS_MUNICIPIOS_FROM_AGS_DEPARTAMENTOS_TITLE',
  'save' => true,
  'id_name' => 'ags_departamentos_ags_municipiosags_departamentos_ida',
  'link' => 'ags_departamentos_ags_municipios',
  'table' => 'ags_departamentos',
  'module' => 'ags_departamentos',
  'rname' => 'name',
);
$dictionary["ags_municipios"]["fields"]["ags_departamentos_ags_municipiosags_departamentos_ida"] = array (
  'name' => 'ags_departamentos_ags_municipiosags_departamentos_ida',
  'type' => 'link',
  'relationship' => 'ags_departamentos_ags_municipios',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_AGS_DEPARTAMENTOS_AGS_MUNICIPIOS_FROM_AGS_MUNICIPIOS_TITLE',
);
