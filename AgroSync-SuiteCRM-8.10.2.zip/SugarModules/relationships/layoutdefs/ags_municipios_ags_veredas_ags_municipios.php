<?php
 // created: 2026-11-19 15:41:47
$layout_defs["ags_municipios"]["subpanel_setup"]['ags_municipios_ags_veredas'] = array (
  'order' => 100,
  'module' => 'ags_veredas',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AGS_MUNICIPIOS_AGS_VEREDAS_FROM_AGS_VEREDAS_TITLE',
  'get_subpanel_data' => 'ags_municipios_ags_veredas',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
