<?php
 // created: 2026-11-19 15:41:47
$layout_defs["ags_departamentos"]["subpanel_setup"]['ags_departamentos_ags_municipios'] = array (
  'order' => 100,
  'module' => 'ags_municipios',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AGS_DEPARTAMENTOS_AGS_MUNICIPIOS_FROM_AGS_MUNICIPIOS_TITLE',
  'get_subpanel_data' => 'ags_departamentos_ags_municipios',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
