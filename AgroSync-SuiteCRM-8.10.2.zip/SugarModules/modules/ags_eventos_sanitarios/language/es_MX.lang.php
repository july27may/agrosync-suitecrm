<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2018 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Asignado a usuario con Id',
  'LBL_ASSIGNED_TO_NAME' => 'Asignado a',
  'LBL_SECURITYGROUPS' => 'Grupos de Seguridad',
  'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => 'Grupos de Seguridad',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Fecha de creación',
  'LBL_DATE_MODIFIED' => 'Fecha de modificación',
  'LBL_MODIFIED' => 'Modificado por',
  'LBL_MODIFIED_NAME' => 'Modificado por nombre',
  'LBL_CREATED' => 'Creado por',
  'LBL_DESCRIPTION' => 'Observaciones',
  'LBL_DELETED' => 'Eliminado',
  'LBL_NAME' => 'Nombre del evento',
  'LBL_CREATED_USER' => 'Creado por usuario',
  'LBL_MODIFIED_USER' => 'Modificado por usuario',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_REMOVE' => 'Quitar',
  'LBL_ASCENDING' => 'Ascendente',
  'LBL_DESCENDING' => 'Descendente',
  'LBL_OPT_IN' => 'Autorizar',
  'LBL_OPT_IN_PENDING_EMAIL_NOT_SENT' => 'Autorización pendiente. Confirmación no enviada',
  'LBL_OPT_IN_PENDING_EMAIL_SENT' => 'Autorización pendiente. Confirmación ya enviada',
  'LBL_OPT_IN_CONFIRMED' => 'Autorizado',
  'LBL_LIST_FORM_TITLE' => 'Eventos sanitarios',
  'LBL_MODULE_NAME' => 'Eventos sanitarios',
  'LBL_MODULE_TITLE' => 'Eventos sanitarios',
  'LBL_HOMEPAGE_TITLE' => 'Mi ',
  'LNK_NEW_RECORD' => 'Crear evento sanitario',
  'LNK_LIST' => 'Ver eventos sanitarios',
  'LNK_IMPORT_AGS_EVENTOS_SANITARIOS' => 'Importar ',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar en eventos sanitarios',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historial',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_AGS_EVENTOS_SANITARIOS_SUBPANEL_TITLE' => 'Eventos sanitarios',
  'LBL_NEW_FORM_TITLE' => 'Crear evento sanitario',
  'LBL_ANIMAL' => 'Animal',
  'LBL_ANIMAL_ID' => 'Animal (ID)',
  'LBL_FECHA' => 'Fecha del evento',
  'LBL_TIPO_EVENTO' => 'Tipo de evento',
  'LBL_PRODUCTO' => 'Producto o procedimiento',
  'LBL_RESPONSABLE' => 'Responsable',
  'LBL_RESPONSABLE_ID' => 'Responsable (ID)',
  'LBL_REFERENCIA_CERTIFICADO' => 'Referencia del certificado',
);